# `mix hex.outdated`
[🔗](https://github.com/hexpm/hex/blob/v2.5.1/lib/mix/tasks/hex.outdated.ex#L1)

Shows all Hex dependencies that have newer versions in the registry.

    $ mix hex.outdated [APP]

By default, it only shows top-level packages explicitly listed in the
`mix.exs` file. All outdated packages can be displayed by using the `--all`
command line option.

By default, `hex.outdated` will exit with a non-zero exit code (1) if there are any
outdated dependencies. You can override this to respect the requirements
as specified in your `mix.exs` file, with the `--within-requirements` command line option,
so it only exits with non-zero exit code if the update is possible.

If a `:cooldown` is configured (see `mix hex.config`) and the latest version of a
dependency falls within the cooldown window, the row is annotated with `(cooldown)`
and the version is listed under "Versions in cooldown". Cooldown-held updates do
not contribute to the non-zero exit code — `mix deps.update` would not pick them
up until they age out of the window.

For example, if your version requirement is "~> 2.0" but the latest version is `3.0`,
with `--within-requirements` it will exit successfully, but if the latest version
is `2.8`, then `--within-requirements` will exit with non-zero exit code (1).

One scenario this could be useful is to ensure you always have the latest
version of your dependencies, except for major version bumps.

If a dependency name is given all requirements on that dependency, from
the entire dependency tree, are listed. This is useful if you are trying
to figure why a package isn't updating when you run `mix deps.update`.

Note that when this task determines if a package is updatable it only looks
at the project's current set of dependency requirements and what version
they are locked to. When `mix deps.update` is called multiple packages may
be updated that in turn update their own dependencies, which may cause the
package you want to update to not be able to update. If you want to force
a dependency to be updated to a given version, you can directly update it
in your `mix.exs`.

> In a project, this task must be invoked before any other tasks
> that may load or start your application. Otherwise, you must
> explicitly list `:hex` as part of your `:extra_applications`.

## Command line options

  * `--all` - shows all outdated packages, including children of packages defined in `mix.exs`
  * `--pre` - include pre-releases when checking for newer versions
  * `--within-requirements` - exit with non-zero code only if requirements specified in `mix.exs` is met.
  * `--sort <column>` - sort results by the given column. Currently supports `status`.
  * `--only ANYVALUE` - show only dependencies with the given only value (comma-separated for multiple values)
  * `--json` - output the result as JSON instead of a human readable table. Requires OTP 27 or later.

---

*Consult [api-reference.md](api-reference.md) for complete listing*
