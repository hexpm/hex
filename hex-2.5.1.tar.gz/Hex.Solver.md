# `Hex.Solver`
[🔗](https://github.com/hexpm/hex/blob/v2.5.1/lib/hex/solver.ex#L3)

# `constraint`

```elixir
@opaque constraint()
```

# `dependency`

```elixir
@type dependency() :: %{
  repo: repo(),
  name: package(),
  constraint: constraint(),
  optional: optional(),
  label: label(),
  dependencies: [dependency()]
}
```

# `label`

```elixir
@type label() :: String.t()
```

# `locked`

```elixir
@type locked() :: %{
  repo: repo(),
  name: package(),
  version: Version.t(),
  label: label()
}
```

# `optional`

```elixir
@type optional() :: boolean()
```

# `package`

```elixir
@type package() :: String.t()
```

# `repo`

```elixir
@type repo() :: String.t() | nil
```

# `result`

```elixir
@type result() :: %{required(package()) =&gt; {Version.t(), repo()}}
```

# `parse_constraint`

```elixir
@spec parse_constraint(String.t() | Version.t() | Version.Requirement.t()) ::
  {:ok, constraint()} | :error
```

Parses or converts a SemVer version or Elixir version requirement to an internal solver constraint
that can be returned by the `Hex.Solver.Registry` or passed to `Hex.Solver.run/4`.

# `parse_constraint!`

```elixir
@spec parse_constraint!(String.t() | Version.t() | Version.Requirement.t()) ::
  constraint()
```

Parses or converts a SemVer version or Elixir version requirement to an internal solver constraint
that can be returned by the `Hex.Solver.Registry` or passed to `Hex.Solver.run/4`.

# `run`

```elixir
@spec run(module(), [dependency()], [locked()], [label()], [{:ansi, boolean()}]) ::
  {:ok, result()} | {:error, String.t()}
```

Runs the version solver.

Takes a `Hex.Solver.Registry` implementation, a list of root dependencies, a list of locked
package versions, and a list of packages that are overridden by the root dependencies.

Depdendencies with sub-dependencies in the `:dependencies` map field are not expected to be
packages in the registry. These dependencies are used to give better error messages for
when there are multiple declarations of the dependency with conflicting version requirements.
For example:

    * Top dependency 1
      * package ~> 1.0
    * Top dependency 2
      * package ~> 2.0

Locked dependencies are treated as optional dependencies with a single version as
their constraint.

The overrides are a set of labels. If a dependency with a matching label is declared the
solver will ignore that dependency unless it's a root dependency.

Returns a map of packages and their selected versions or a human readable explanation of
why a solution could not be found.

## Options

  * `:ansi` - If `true` adds ANSI formatting to the failure message (Default: `false`)

---

*Consult [api-reference.md](api-reference.md) for complete listing*
