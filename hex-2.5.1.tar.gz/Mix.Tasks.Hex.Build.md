# `mix hex.build`
[🔗](https://github.com/hexpm/hex/blob/v2.5.1/lib/mix/tasks/hex.build.ex#L1)

Builds a new local version of your package.

The package .tar file is created in the current directory, but is not pushed
to the repository. An app named `foo` at version `1.2.3` will be built as
`foo-1.2.3.tar`.

    $ mix hex.build

## Configuration

* `:app` - Package name (required).
* `:version` - Package version (required).
* `:deps` - List of package dependencies (see [Dependencies](#module-dependencies) below).
* `:description` - Short description of the project.
* `:package` - Hex specific configuration (see [Package configuration](#module-package-configuration) below).

## Dependencies

Dependencies are defined in mix's dependency format. But instead of using
`:git` or `:path` as the SCM `:package` is used.

    defp deps() do
      [
        {:ecto, "~> 0.1.0"},
        {:postgrex, "~> 0.3.0"},
        {:cowboy, github: "extend/cowboy"}
      ]
    end

As can be seen Hex package dependencies works alongside git dependencies.
Important to note is that non-Hex dependencies will not be used during
dependency resolution and neither will they be listed as dependencies of the
package.

## Package configuration

Additional metadata of the package can optionally be defined, but it is very recommended to do so.

  * `:name` - Set this if the package name is not the same as the application
     name.
  * `:files` - List of files and directories to include in the package,
    can include wildcards. Defaults to `["lib", "priv", ".formatter.exs", "mix.exs", "README*", "readme*", "LICENSE*", "license*", "CHANGELOG*", "changelog*", "src", "c_src", "Makefile*"]`.
  * `:exclude_patterns` - List of patterns matching files and directories to
    exclude from the package.
  * `:licenses` - List of licenses used by the package. Use SPDX license
    identifiers or `LicenseRef-<idstring>` for custom licenses included in
    the package.
  * `:links` - Map of links relevant to the package.
  * `:build_tools` - List of build tools that can build the package. Hex will
    try to automatically detect the build tools based on the files in the
    package. If a `rebar` or `rebar.config` file is present Hex will mark it
    as able to build with rebar. This detection can be overridden by setting
    this field.

> In a project, this task must be invoked before any other tasks
> that may load or start your application. Otherwise, you must
> explicitly list `:hex` as part of your `:extra_applications`.

### Command line options

  * `--unpack` - Builds the tarball and unpacks contents into a directory.
    Useful for making sure the tarball contains all needed files before
    publishing. See `--output` below for setting the output path.

  * `-o`, `--output` - Sets output path. When used with `--unpack` it means
    the directory (Default: `<app>-<version>`). Otherwise, it specifies
    tarball path (Default: `<app>-<version>.tar`)

---

*Consult [api-reference.md](api-reference.md) for complete listing*
