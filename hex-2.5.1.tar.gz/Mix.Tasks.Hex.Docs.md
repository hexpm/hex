# `mix hex.docs`
[🔗](https://github.com/hexpm/hex/blob/v2.5.1/lib/mix/tasks/hex.docs.ex#L1)

Fetches or opens documentation of a package.

If no version is specified, defaults to version used in the current mix project.
If called outside of a mix project or the dependency is not used in the
current mix project, defaults to the latest version.

## Fetch documentation for all dependencies in the current mix project

    $ mix hex.docs fetch

## Fetch documentation for offline use

Fetches documentation for the specified package that you can later open with
`mix hex.docs offline`.

    $ mix hex.docs fetch PACKAGE [VERSION]

## Open a browser window with offline documentation

    $ mix hex.docs offline PACKAGE [VERSION]

## Open a browser window with online documentation

    $ mix hex.docs online PACKAGE [VERSION]

## Command line options

  * `--page "Some.Module"`, `--page guide` - Open a specified documentation page inside desired package
  * `--organization ORGANIZATION` - Set this for private packages belonging to an organization
  * `--latest` - Looks for the latest release of a package
  * `--format epub`, `--format md` - When opening documentation offline, use this flag to open the epub/md formatted version

---

*Consult [api-reference.md](api-reference.md) for complete listing*
