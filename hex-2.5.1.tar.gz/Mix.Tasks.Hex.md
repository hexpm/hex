# `mix hex`
[🔗](https://github.com/hexpm/hex/blob/v2.5.1/lib/mix/tasks/hex.ex#L1)

Prints Hex tasks and their information.

    $ mix hex

See `mix help hex.config` to see all available configuration options.

---

*Consult [api-reference.md](api-reference.md) for complete listing*
