# `mix hex.policy`
[🔗](https://github.com/hexpm/hex/blob/v2.5.1/lib/mix/tasks/hex.policy.ex#L1)

Shows the active Hex policy and explains why specific versions
are blocked.

    $ mix hex.policy show
    $ mix hex.policy why PACKAGE

## Commands

  * `show` — Summarize the active policy: visibility and the
    per-repository restrictions (cooldown, advisory, retirement) and
    the package overrides, plus the effective cooldown.
  * `why PACKAGE` — Walk every version of the named package in the
    registry, classify each against the active policy, and print a
    per-version table of status and the reasons it is blocked.

## Opting in

A project opts into a single policy. It is configured like any other
Hex setting, with the usual precedence (`HEX_POLICY` env var, then
`mix.exs`, then `mix hex.config`):

  * `mix.exs` `:hex` block, with `org:` for a hexpm organization or
    `repo:` for any configured repo:

        defp project() do
          [hex: [policy: [org: "myorg", name: "strict-prod"]]]
        end

  * `HEX_POLICY` env var (a `REPO/NAME` pair). An empty value disables
    the configured policy for the invocation:

        $ HEX_POLICY=hexpm:myorg/strict-prod mix deps.get

  * `mix hex.config`:

        $ mix hex.config policy hexpm:myorg/strict-prod

See https://hex.pm/docs/dependency-policies for the full guide.

---

*Consult [api-reference.md](api-reference.md) for complete listing*
