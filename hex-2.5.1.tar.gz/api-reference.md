# Hex v2.5.1 - API Reference

## Modules

- [Hex.Solver](Hex.Solver.md)
- [Hex.Solver.Registry](Hex.Solver.Registry.md)

## Mix Tasks

- [mix hex](Mix.Tasks.Hex.md): Prints Hex tasks and their information.
- [mix hex.audit](Mix.Tasks.Hex.Audit.md): Shows all Hex dependencies that have been marked as retired or have
security advisories.
- [mix hex.build](Mix.Tasks.Hex.Build.md): Builds a new local version of your package.
- [mix hex.config](Mix.Tasks.Hex.Config.md): Reads, updates or deletes local Hex config.
- [mix hex.docs](Mix.Tasks.Hex.Docs.md): Fetches or opens documentation of a package.
- [mix hex.info](Mix.Tasks.Hex.Info.md): Prints Hex package or system information.
- [mix hex.organization](Mix.Tasks.Hex.Organization.md): Manages the list of authorized Hex.pm organizations.
- [mix hex.outdated](Mix.Tasks.Hex.Outdated.md): Shows all Hex dependencies that have newer versions in the registry.
- [mix hex.owner](Mix.Tasks.Hex.Owner.md): Adds, removes or lists package owners.
- [mix hex.package](Mix.Tasks.Hex.Package.md): Fetches or diffs packages.
- [mix hex.policy](Mix.Tasks.Hex.Policy.md): Shows the active Hex policy and explains why specific versions
are blocked.
- [mix hex.publish](Mix.Tasks.Hex.Publish.md): Publishes a new version of the package.
- [mix hex.registry](Mix.Tasks.Hex.Registry.md): Manages local Hex registries.
- [mix hex.repo](Mix.Tasks.Hex.Repo.md): Manages the list of available Hex repositories.
- [mix hex.retire](Mix.Tasks.Hex.Retire.md): Retires a package version.
- [mix hex.search](Mix.Tasks.Hex.Search.md): Open and perform searches.
- [mix hex.sponsor](Mix.Tasks.Hex.Sponsor.md): Show Hex packages in your dependencies that accept sponsorships.
- [mix hex.user](Mix.Tasks.Hex.User.md): Hex user tasks.

