# `mix hex.repo`
[🔗](https://github.com/hexpm/hex/blob/v2.5.1/lib/mix/tasks/hex.repo.ex#L1)

Manages the list of available Hex repositories.

The repository is where packages and the registry of packages is stored.
You can fetch packages from multiple different repositories and packages
can depend on packages from other repositories. To use a package from another
repository than the global default `hexpm` add `repo: "my_repo"` to the
dependency declaration in `mix.exs`:

    {:plug, "~> 1.0", repo: "my_repo"}

By default all dependencies of plug will also be fetched from `my_repo`
unless plug has declared otherwise in its dependency definition.

To use packages from `my_repo` you need to add it to your configuration
first. You do that by calling `mix hex.repo add my_repo https://myrepo.example.com`.

The default repo is called `hexpm` and points to https://repo.hex.pm. This
can be overridden by using `mix hex.repo set ...`.

A repository configured from an organization will have `hexpm:` prefixed to
its name. To depend on packages from an organization add `repo: "hexpm:my_organization"`
to the dependency declaration or simply `organization: "my_organization"`.

To configure organizations, see the `hex.organization` task.

## Add a repo

    $ mix hex.repo add NAME URL

### Command line options

  * `--public-key PATH` - Path to public key used to verify the registry (optional).

  * `--auth-key KEY` - Key used to authenticate HTTP requests to repository (optional).

  * `--fetch-public-key FINGERPRINT` - Download public key from the repository and verify against the fingerprint (optional).

  * `--oauth-exchange` - Enable OAuth token exchange for API keys. Exchange the API key for a short-lived OAuth token
    instead of using the API key directly. Defaults to enabled for hexpm, disabled for other repositories.
    In the future, this will default to enabled for all repositories (optional).

  * `--no-oauth-exchange` - Disable OAuth token exchange for API keys. Use the API key directly instead of exchanging
    it for a short-lived OAuth token. Currently a no-op, but will disable OAuth token exchange  in the future (optional).

  * `--oauth-exchange-url URL` - Custom URL for OAuth token exchange. By default, the API URL is used (optional).

## Set config for repo

    $ mix hex.repo set NAME --url URL
    $ mix hex.repo set NAME --public-key PATH
    $ mix hex.repo set NAME --auth-key KEY
    $ mix hex.repo set NAME --oauth-exchange
    $ mix hex.repo set NAME --no-oauth-exchange
    $ mix hex.repo set NAME --oauth-exchange-url URL

## Remove repo

    $ mix hex.repo remove NAME

## Show repo config

    $ mix hex.repo show NAME
    $ mix hex.repo show NAME --url

## List all repos

    $ mix hex.repo list

---

*Consult [api-reference.md](api-reference.md) for complete listing*
