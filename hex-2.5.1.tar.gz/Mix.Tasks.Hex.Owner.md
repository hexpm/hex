# `mix hex.owner`
[🔗](https://github.com/hexpm/hex/blob/v2.5.1/lib/mix/tasks/hex.owner.ex#L1)

Adds, removes or lists package owners.

Package owners have full permissions to the package. They can publish and
revert releases and even remove other package owners.

## Add owner

Adds an owner to package by specifying the package name and email or username
of the new owner. This command also takes a `--level` option, see below for more
details.

    $ mix hex.owner add PACKAGE EMAIL_OR_USERNAME

## Transfer ownership

Like `mix hex.owner add` but also removes all existing owners of the package.
This task is required to use when transferring ownership of the package to an
organization.

    $ mix hex.owner transfer PACKAGE EMAIL_OR_USERNAME

## Remove owner

Removes an owner to package by specifying the package name and email or username
of the new owner.

    $ mix hex.owner remove PACKAGE EMAIL_OR_USERNAME

## List owners

Lists all owners of given package.

    $ mix hex.owner list PACKAGE

## List owned packages

Lists all packages owned by the current user.

    $ mix hex.owner packages

## Command line options

  * `--level maintainer` - Maintainer level owners have all the powers of package ownership,
    except they cannot add or remove other package owners
  * `--level full` - Over the maintainer level, full owners can also add and remove other
    package owners (default)
  * `--organization ORGANIZATION` - Set this for private packages belonging to an organization

---

*Consult [api-reference.md](api-reference.md) for complete listing*
