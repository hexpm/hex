# `mix hex.organization`
[🔗](https://github.com/hexpm/hex/blob/v2.5.1/lib/mix/tasks/hex.organization.ex#L1)

Manages the list of authorized Hex.pm organizations.

Organizations is a feature of Hex.pm to host and manage private packages. See
<https://hex.pm/docs/private> for more information.

By default you will be authorized to all your applications when running
`mix hex.user auth` and this is the recommended approach. This task is mainly
provided for CI and build systems where access to an organization is needed
without authorizing a user.

For CI, generate an organization key with `mix hex.organization key ORGANIZATION generate`
and pass it with `mix hex.organization auth ORGANIZATION --key KEY`.

> #### Deprecation {: .warning}
>
> Authorizing an organization without `--key` is deprecated and will be removed.
> It creates a user key tied to your account; use `mix hex.user auth` for
> development instead, or pass a pre-generated organization key with `--key` for CI.

To use a package from an organization add `organization: "my_organization"` to the
dependency declaration in `mix.exs`:

    {:plug, "~> 1.0", organization: "my_organization"}

## Authorize an organization

This command will generate an API key used to authenticate access to the organization.
See the `hex.user` tasks to list and control all your active API keys.

    $ mix hex.organization auth ORGANIZATION  [--key KEY] [--key-name KEY_NAME]

## Deauthorize and remove an organization

    $ mix hex.organization deauth NAME

## List all authorized organizations

This command will only list organizations you have authorized with this task, it will not
list organizations you have access to by having authorized with `mix hex.user auth`.

    $ mix hex.organization list

## Generate organization key

This command is useful to pre-generate keys for use with `mix hex.organization auth ORGANIZATION --key KEY`
on CI servers or similar systems. It returns the hash of the generated key that you can pass to
`auth ORGANIZATION --key KEY`. Unlike the `hex.user key` commands, a key generated with this
command is owned by the organization directly, and not the user that generated it. This makes it
ideal for shared environments such as CI where you don't want to give access to user-specific
resources and the user's organization membership status won't affect key. By default this command
sets the `repository:organization_name` permission which allows read-only access to the organization's repository, it can be
overridden with the `--permission` flag.

    $ mix hex.organization key ORGANIZATION generate [--key-name KEY_NAME] [--permission PERMISSION]

## Revoke key

Removes given key from organization.

The key can no longer be used to authenticate API requests.

    $ mix hex.organization key ORGANIZATION revoke KEY_NAME

## Revoke all keys

Revoke all keys from the organization.

    $ mix hex.organization key ORGANIZATION revoke --all

## List keys

Lists all keys associated with the organization.

    $ mix hex.organization key ORGANIZATION list

## Command line options

  * `--key KEY` - Hash of key used to authenticate HTTP requests to repository, if
    omitted will generate a new key with your account credentials. This flag
    is useful if you have a key pre-generated with `mix hex.organization key`
    and want to authenticate on a CI server or similar system. Omitting `--key`
    is deprecated; authenticate as a user with `mix hex.user auth` instead

  * `--key-name KEY_NAME` - By default Hex will base the key name on your machine's
    hostname and the organization name, use this option to give your own name.

  * `--permission PERMISSION` - Sets the permissions on the key, this option can be given
    multiple times, possibly values are:
    * `api:read` - API read access.
    * `api:write` - API write access.
    * `repository:organization_name` - Access to the organization's repository (this is the default permission).

---

*Consult [api-reference.md](api-reference.md) for complete listing*
