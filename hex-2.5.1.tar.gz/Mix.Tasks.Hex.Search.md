# `mix hex.search`
[🔗](https://github.com/hexpm/hex/blob/v2.5.1/lib/mix/tasks/hex.search.ex#L1)

Open and perform searches.

When invoked without arguments, it opens up a search page on
https://hexdocs.pm with all of your dependencies plus Elixir standard
library selected:

    $ mix hex.search
    $ mix hex.search --no-stdlib
    $ mix hex.search --packages foo,bar

You may also pass command line flags, to execute searches
via the command line, according to the modes below.

For searching package names, see `mix hex.package search`.

## Docs search

Pass a single positional argument to search docs and print results
directly to the terminal.

    $ mix hex.search "ecto changeset"
    $ mix hex.search "ecto changeset" --packages ecto,ecto_sql
    $ mix hex.search "ecto changeset" --limit 25

### Options

  * `--packages PACKAGE1,PACKAGE2,...` - Restrict docs search to an explicit package list
  * `--limit NUMBER` - Limit terminal docs search results (default: 10)
  * `--print-url` - Print the docs URL instead of opening it in the browser

---

*Consult [api-reference.md](api-reference.md) for complete listing*
