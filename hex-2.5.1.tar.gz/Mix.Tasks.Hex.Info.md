# `mix hex.info`
[🔗](https://github.com/hexpm/hex/blob/v2.5.1/lib/mix/tasks/hex.info.ex#L1)

Prints Hex package or system information.

    $ mix hex.info [PACKAGE [VERSION]]

If `package` is not given, print system information. This includes when
registry was last updated and current system version.

If `package` is given, print information about the package. This includes all
released versions and package metadata.

If `package` and `version` is given, print release information.

## Command line options

  * `--organization ORGANIZATION` - Set this for private packages belonging to an organization

---

*Consult [api-reference.md](api-reference.md) for complete listing*
