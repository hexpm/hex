# `mix hex.user`
[🔗](https://github.com/hexpm/hex/blob/v2.5.1/lib/mix/tasks/hex.user.ex#L1)

Hex user tasks.

## Print the current user

    $ mix hex.user whoami

## Authorize a new user

Authorizes a new user on the local machine.

    $ mix hex.user auth

## Deauthorize the user

Deauthorizes the user from the local machine.

    $ mix hex.user deauth

---

*Consult [api-reference.md](api-reference.md) for complete listing*
