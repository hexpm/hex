# `mix hex.sponsor`
[🔗](https://github.com/hexpm/hex/blob/v2.5.1/lib/mix/tasks/hex.sponsor.ex#L1)

Show Hex packages in your dependencies that accept sponsorships.

    $ mix hex.sponsor

Sponsorship plays an important role to maintain some open
source projects. This task will display all packages that
are accepting sponsorship from the current project.

You can add sponsorship links to your projects by adding the
following to your mix.exs:

    links: %{
      "GitHub" => "[your-repo-link]",
      "Sponsor" => "[your-sponsorship-link]"
    }

---

*Consult [api-reference.md](api-reference.md) for complete listing*
