# `mix hex.retire`
[🔗](https://github.com/hexpm/hex/blob/v2.5.1/lib/mix/tasks/hex.retire.ex#L1)

Retires a package version.

    $ mix hex.retire PACKAGE VERSION REASON

    $ mix hex.retire PACKAGE VERSION --unretire

Mark a package as retired when you no longer recommend its usage. A retired
package is still resolvable and usable but it will be flagged as retired in the
repository and a message will be displayed to users when they use the package.

## Retirement reasons

  * **renamed** - The package has been renamed, including the new package name
    in the message
  * **deprecated** - The package has been deprecated, if there's a replacing
    package include it in the message
  * **security** - There are security issues with this package
  * **invalid** - The package is invalid, for example it does not compile correctly
  * **other** - Any other reason not included above, clarify the reason in
    the message

## Command line options

  * `--message "MESSAGE"` - Required message (up to 140 characters) clarifying
    the retirement reason
  * `--organization ORGANIZATION` - Set this for private packages belonging to an organization

## Example

    $ mix hex.retire your_app 0.1.1 invalid --message "Package has a breaking bug"

---

*Consult [api-reference.md](api-reference.md) for complete listing*
