# `Hex.Solver.Registry`
[🔗](https://github.com/hexpm/hex/blob/v2.5.1/lib/hex/solver/registry.ex#L3)

# `dependencies`

```elixir
@callback dependencies(Hex.Solver.repo(), Hex.Solver.package(), Version.t()) ::
  {:ok, [Hex.Solver.dependency()]} | :error
```

Returns all dependencies of the given package version or `:error` if the package or version
does not exist.

# `prefetch`

```elixir
@callback prefetch([{Hex.Solver.repo(), Hex.Solver.package()}]) :: :ok
```

Called when the solver first discovers a set of packages so that the registry can be lazily
preloaded.

# `versions`

```elixir
@callback versions(Hex.Solver.repo(), Hex.Solver.package()) ::
  {:ok, [Version.t()]} | :error
```

Returns all versions of the given package sorted from lowest to highest or `:error` if the package
does not exist.

---

*Consult [api-reference.md](api-reference.md) for complete listing*
